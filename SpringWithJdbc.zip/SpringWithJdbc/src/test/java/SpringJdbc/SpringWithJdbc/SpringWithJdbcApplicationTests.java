package SpringJdbc.SpringWithJdbc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringWithJdbcApplicationTests {

	@Test
	void contextLoads() {
	}

}
